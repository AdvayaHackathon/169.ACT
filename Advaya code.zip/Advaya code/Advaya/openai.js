const OpenAI = require("openai");

// OpenAI Config
const openai = new OpenAI({
    apiKey: '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',
});

async function openAI(userData) {
    const chatCompletion = await openai.chat.completions.create({
        messages: [
            {
                role: 'user',
                content: `You are an AI travel itinerary and city experience assistant. I am a ${userData.age} year old ${userData.gender} currently in ${userData.city}, and I want to explore " ${userData.lookingFor}". Based on my age, gender, and location, recommend the most suitable, engaging, and relevant places to visit and things to do. 
                Understand who I am to infer what kind of places or experiences would be enjoyable, appropriate, and safe for me — whether cultural, historical, adventurous, social, relaxing, or recreational.
                Return the output in a minified JSON array with this format: [{"place_name_here": "place_description"}]`
            },
        ],
        model: 'gpt-3.5-turbo',
    })


    // console.log(chatCompletion); // 
    console.log(chatCompletion.choices[0].message);
    let output = JSON.parse(chatCompletion.choices[0].message.content);
    return output;
}

async function festivals(city, month) {
    console.log(city)
    console.log(month)
    const chatCompletion = await openai.chat.completions.create({
        messages: [
            {
                role: 'user',
                content: `You are an AI travel itinerary and city experience assistant. I am a currently in ${city} in the month of ${month}, and I want to explore major festivals happening here, if there are any festivals happening centrally, those are applicable too
                Return the output in a minified JSON array with this format: [{"name": "festival_name", "description": "festival_desc"}]`
            },
        ],
        model: 'gpt-3.5-turbo',
    })


    // console.log(chatCompletion); // 
    console.log(chatCompletion.choices[0].message);
    let output = JSON.parse(chatCompletion.choices[0].message.content);
    console.log(output)
    return output;
}

// festivals('Punjab', 'April').then(res => {
//     console.log(res)
// })

module.exports = { openAI, festivals }