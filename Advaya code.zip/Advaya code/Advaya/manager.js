const fs = require('fs');

function getUsername(uid) {
    let users = JSON.parse(fs.readFileSync('db/users.json', 'utf8'));
    let index = users.findIndex(e => e.id == uid);

    if (index == -1) {
        return false;
    } else {
        return users[index].username;
    }
}

// console.log(getUsername('eYEg4KoEY6mDDfUTcWyvw7Gu'))
module.exports = { getUsername }